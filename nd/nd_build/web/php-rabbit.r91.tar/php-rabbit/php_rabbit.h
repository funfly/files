/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2007 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Alexandre Kalendarev akalend@mail.ru    Copyright (c) 2009   |
  +----------------------------------------------------------------------+
*/

/* $Id: header,v 1.16.2.1.2.1 2007/01/01 19:32:09 iliaa Exp $ */

#ifndef PHP_RABBIT_H
#define PHP_RABBIT_H

extern zend_module_entry rabbit_module_entry;
#define phpext_rabbit_ptr &rabbit_module_entry

#ifdef PHP_WIN32
#define PHP_RABBIT_API __declspec(dllexport)
#else
#define PHP_RABBIT_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

#define  AMQP_NOPARM		1

#define  AMQP_DURABLE		2
#define  AMQP_PASSIVE		4
#define  AMQP_EXCLUSIVE		8
#define  AMQP_AUTODELETE	16
#define  AMQP_INTERNAL		32
#define  AMQP_NOLOCAL		64
#define  AMQP_NOACK			128
#define  AMQP_IFEMPTY		256
#define  AMQP_IFUNUSED		528
#define  AMQP_MANDATORY		1024
#define  AMQP_IMMEDIATE		2048

PHP_MINIT_FUNCTION(rabbit);
PHP_MSHUTDOWN_FUNCTION(rabbit);
PHP_MINFO_FUNCTION(rabbit);
	
PHP_METHOD( rabbit_class, __construct);
PHP_METHOD( rabbit_class, isConnected);

PHP_METHOD( rabbit_queue_class, __construct);
PHP_METHOD( rabbit_queue_class, declare);
PHP_METHOD( rabbit_queue_class, consume);
PHP_METHOD( rabbit_queue_class, delete);
PHP_METHOD( rabbit_queue_class, purge);
PHP_METHOD( rabbit_queue_class, bind);
PHP_METHOD( rabbit_queue_class, unbind);
PHP_METHOD( rabbit_queue_class, get);
PHP_METHOD( rabbit_queue_class, cancel);

PHP_METHOD( rabbit_exchange_class, __construct);
PHP_METHOD( rabbit_exchange_class, declare);
PHP_METHOD( rabbit_exchange_class, delete);
PHP_METHOD( rabbit_exchange_class, bind);
PHP_METHOD( rabbit_exchange_class, publish);


#ifdef ZTS
#define RABBIT_G(v) TSRMG(rabbit_globals_id, zend_rabbit_globals *, v)
#else
#define RABBIT_G(v) (rabbit_globals.v)
#endif

#endif	/* PHP_RABBIT_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
