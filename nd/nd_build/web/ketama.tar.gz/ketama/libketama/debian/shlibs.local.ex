liblibketama 1.0 libketama (>> 1.0-0), libketama (<< 1.0-99)
