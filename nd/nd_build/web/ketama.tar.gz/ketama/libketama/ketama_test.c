/*
 * Using a known ketama.servers file, and a fixed set of keys
 * print and hash the output of this program using your modified
 * libketama, compare the hash of the output to the known correct
 * hash in the test harness.
 *
 */

#include <ketama.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  return 0;
}
