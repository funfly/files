/*
 ============================================================================
 Name        : ketama1.c
 Author      : tt
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "ketama.h"

int main(void)
{
	puts("!!!Hello World!!!---"); /* prints !!!Hello World!!! */

	serverlist* slist;
	if(ketama_serverlist_init(&slist, 123456) < 0)
	{
		puts(ketama_error());
	}

	if(ketama_add_server(slist, "server1", 1) <0)
	{
		puts(ketama_error());
	}

	ketama_add_server(slist, "server2", 1);
	ketama_add_server(slist, "server3", 1);
	ketama_add_server(slist, "server4", 1);

	ketama_continuum cont;
	ketama_roll(&cont, slist);

	mcs* mcs1 = ketama_get_server(cont, "0001");
	mcs* mcs2 = ketama_get_server(cont, "1002");
	mcs* mcs3 = ketama_get_server(cont, "03");
	mcs* mcs4 = ketama_get_server(cont, "3004");
	mcs* mcs5 = ketama_get_server(cont, "4005");
	mcs* mcs6 = ketama_get_server(cont, "66");

	if(mcs1 == NULL) printf("mcs1 is null\n");

	printf("0001 server is:%s,point is:%u\n",mcs1->name,mcs1->point);
	printf("0002 server is:%s,point is:%u\n",mcs2->name,mcs2->point);
	printf("0003 server is:%s,point is:%u\n",mcs3->name,mcs3->point);
	printf("0004 server is:%s,point is:%u\n",mcs4->name,mcs4->point);
	printf("0005 server is:%s,point is:%u\n",mcs5->name,mcs5->point);
	printf("0006 server is:%s,point is:%u\n",mcs6->name,mcs6->point);

	return EXIT_SUCCESS;
}
