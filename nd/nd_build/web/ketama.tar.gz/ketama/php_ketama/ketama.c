/*
  +----------------------------------------------------------------------+
  | PHP Version 4                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2006 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Christian Muehlhaeuser <chris@last.fm>                       |
  +----------------------------------------------------------------------+
*/

/* $Id: header,v 1.10.8.1.4.1 2006/01/01 13:46:48 sniper Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_ketama.h"
#include "ketama.h"

/* If you declare any globals in php_ketama.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(ketama)
*/

/* True global resources - no need for thread safety here */
static int le_ketama_serverlist;

static void ketama_serverlist_destroy( zend_rsrc_list_entry *rsrc TSRMLS_DC )
{
	serverlist* slist = (serverlist*)rsrc->ptr;
	ketama_smoke_serverlist( slist );
}

/* {{{ ketama_functions[]
 *
 * Every user visible function must have an entry in ketama_functions[].
 */
zend_function_entry ketama_functions[] = {
	PHP_FE(ketama_serverlist_init,  NULL)
	PHP_FE(ketama_add_server,       NULL)
	PHP_FE(ketama_roll,		        NULL)
	PHP_FE(ketama_get_server,	    NULL)
    PHP_FE(ketama_error,            NULL)
	{NULL, NULL, NULL}	/* Must be the last line in ketama_functions[] */
};
/* }}} */

/* {{{ ketama_module_entry
 */
zend_module_entry ketama_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"ketama",
	ketama_functions,
	PHP_MINIT(ketama),
	PHP_MSHUTDOWN(ketama),
	PHP_RINIT(ketama),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(ketama),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(ketama),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_KETAMA
ZEND_GET_MODULE(ketama)
#endif

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("ketama.global_value",      "42", PHP_INI_ALL, OnUpdateInt, global_value, zend_ketama_globals, ketama_globals)
    STD_PHP_INI_ENTRY("ketama.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_ketama_globals, ketama_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_ketama_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_ketama_init_globals(zend_ketama_globals *ketama_globals)
{
	ketama_globals->global_value = 0;
	ketama_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(ketama)
{
	/* If you have INI entries, uncomment these lines 
	ZEND_INIT_MODULE_GLOBALS(ketama, php_ketama_init_globals, NULL);
	REGISTER_INI_ENTRIES();
	*/
	le_ketama_serverlist = zend_register_list_destructors_ex(ketama_serverlist_destroy, NULL, "ketama serverlist", module_number);

	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(ketama)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(ketama)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(ketama)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(ketama)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "ketama support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */

/* {{{ proto resource ketama_serverlist_init()
   init the ketama serverlist */
PHP_FUNCTION(ketama_serverlist_init)
{
	long key;
	double version;

	if ( zend_parse_parameters( ZEND_NUM_ARGS() TSRMLS_CC, "ld", &key, &version ) == FAILURE )
	{
		return;
	}

	serverlist* slist;


	if ( ketama_serverlist_init( &slist, key, version ) != 1)
	{
		php_error_docref(NULL TSRMLS_CC, E_ERROR, " init the ketama serverlist error");
	} 
	else 
	{
		ZEND_REGISTER_RESOURCE( return_value, slist, le_ketama_serverlist );
	}
}
/* }}} */

/* {{{ proto resource ketama_serverlist_clear()
   init the ketama serverlist */
PHP_FUNCTION(ketama_serverlist_clear)
{

	zval *r;
	serverlist *slist;

	if ( zend_parse_parameters( ZEND_NUM_ARGS() TSRMLS_CC, "r", &r ) == FAILURE )
	{
		return;
	}

	ZEND_FETCH_RESOURCE( slist, serverlist*, &r, -1, "ketama serverlist", le_ketama_serverlist );
	ketama_serverlist_clear(slist);

}
/* }}} */

/* {{{ proto resource ketama_add_server()
   add the server to serverlist */
PHP_FUNCTION(ketama_add_server)
{
	zval* slist_val;
	serverlist* slist;
	char *servername;
	long servername_len;
	long memory;
	long ret;

	if ( zend_parse_parameters( ZEND_NUM_ARGS() TSRMLS_CC, "rsl",&slist_val, &servername, &servername_len, &memory ) == FAILURE )
	{
		return;
	}

	ZEND_FETCH_RESOURCE( slist, serverlist*, &slist_val, -1, "ketama serverlist", le_ketama_serverlist );
	ret = ketama_add_server( slist, servername, memory);	

	if ( !ret )
	{
		php_error_docref(NULL TSRMLS_CC, E_ERROR, "unable to ketama_add_server");
	}
	else
	{
		RETURN_LONG(ret);
	}
}
/* }}} */

/* {{{ proto resource ketama_roll()
   Rolls the ketama */
PHP_FUNCTION(ketama_roll)
{
	zval *slist_val;
	
	if ( zend_parse_parameters( ZEND_NUM_ARGS() TSRMLS_CC, "r", &slist_val ) == FAILURE )
	{
		return;
	}
	
	serverlist *slist;

	ZEND_FETCH_RESOURCE( slist, serverlist*, &slist_val, -1, "ketama serverlist", le_ketama_serverlist );
	
	ketama_continuum continuum;

	long ret = ketama_roll( &continuum, slist );
	
	if ( !ret )
	{
		php_error_docref(NULL TSRMLS_CC, E_ERROR, "unable to create Ketama continuum");	
	}
}
/* }}} */


/* {{{ proto resource ketama_get_server(key_t key,string $name)
   Finds a server for the given key in the continuum */
PHP_FUNCTION(ketama_get_server)
{
	long key;
	char *name;
	long name_len;
	mcs* mcsptr;	
	mcs retmcs;
	
	if ( zend_parse_parameters( ZEND_NUM_ARGS() TSRMLS_CC, "ls", &key, &name, &name_len) == FAILURE )
	{
		return;
	}

	mcsptr = ketama_get_server(key, name);


	if(mcsptr==0)
	{		
		retmcs.point= 0;
		retmcs.name[0]='\0';
	}
	else
	{
		retmcs.point= mcsptr->point;
		strncpy(retmcs.name, mcsptr->name,sizeof(mcsptr->name)-1);
	}
		
	ketama_smoke_mcs(mcsptr);  //release object
	
	array_init( return_value );
	add_assoc_long( return_value, "point",  retmcs.point);
	add_assoc_string( return_value, "name", retmcs.name, 1);
}
/* }}} */


/* {{{ proto resource ketama_error()
   Prints the latest ketama error */
PHP_FUNCTION(ketama_error)
{
    RETURN_STRING( (char *)ketama_error(), 1 );
}
/* }}} */


/* The previous line is meant for vim and emacs, so it can correctly fold and 
   unfold functions in source code. See the corresponding marks just before 
   function definition, where the functions purpose is also documented. Please 
   follow this convention for the convenience of others editing your code.
*/


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
