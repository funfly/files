<?php
echo "Starting<br/>";

// try loading server definitions from specified file.
// ketama_roll will automatically re-read the contents
// whenever the file changes.

$serverlist = ketama_serverlist_init(123123);

ketama_add_server($serverlist,"server1",1);
ketama_serverlist_clear($serverlist);
ketama_add_server($serverlist,"server2",1);
ketama_add_server($serverlist,"server3",1);
ketama_add_server($serverlist,"server4",1);

$continuum = ketama_roll($serverlist);

echo 'ketama runs well!<br/>';

//if ( $continuum )	die( "Continuum doesn't exist!\n" );

// find the matching server for key $i in the continuum
// specified by resource $continuum.
for ( $i = 0; $i < 25; $i++ )
{
	$server = ketama_get_server( $continuum, $i );
	echo "Key " .$i. " is mapped to server " . $server[ "name" ] . " at point: " . $server[ "point" ] . "<br/>";
}

// not strictly needed (will be auto-cleaned)
ketama_serverlist_smoke($serverlist);
ketama_smoke( $continuum );

echo "Finished\n";
?>
