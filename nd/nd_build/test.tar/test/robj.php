<?php

require 'fcgi.php';

class RemoteException extends Exception {
	public function __construct($stderr, $appStatus) {
		parent::__construct($stderr, $appStatus);
	}
}

class RemoteObject {
	private $class = null;
	private $fcgiClient = null;
	private $request = null;
	
	public function __construct($class, $config) {
		$this->class = $class;
		$this->fcgiClient = new FastCgiClient($config->host, $config->port);
		$this->request = $request = new FastCgiRequest($config->agent);
	}
	
	public function __destruct() {
		if (!is_null($this->fcgiClient)) {
			$this->fcgiClient->close();
		}
	}
	
	public function execute($method, $params) {
		$content = array(
			'class' => $this->class,
			'method' => $method,
			'params' => $params,
		);
		$this->request->setContent(json_encode($content));
		
		$response = $this->fcgiClient->execute($this->request);
		if (!is_null($response->stderr)) {
			throw new RemoteException($response->stderr, $response->appStatus);
		}
				
		$result = new stdClass();
		$result->statusCode = $response->appStatus;
		
		$i = 0;
		$lines = explode("\n", $response->stdout);
		$count = count($lines);
		
		for (; $i < $count; $i++) {
			if (strlen($lines[$i]) <= 1) {
				break;
			}
		}
		
		$text = null;
		for ($i++; $i < $count; $i++) {
			$text .= $lines[$i];
		}
		
		$results = json_decode($text);
		if (is_null($results) && !is_null($text)) {
			throw new RemoteException($text, 1);
		}
		
		return $results;
	}
	
	public function __call($method, $params) {
		return $this->execute($method, $params);
	}	
}

