#!/usr/local/webserver/php-5.3.10/bin/php
<?php
    require('fcgi.php');
try{
    $config = new stdClass();
    $config->host = 'localhost';
    $config->port = 9900;
    $config->script = "/tmp/test.php";
    
    $fcgiClient = new FastCgiClient($config->host, $config->port);
    $request = new FastCgiRequest($config->script, 'test');
    $response = $fcgiClient->execute($request);
    print($response->stdout);
    
    $fcgiClient->close();
} catch (Exception $e) {
    print_r($e);
}
?>

