<?php

define('FCGI_VERSION_1', 1);
define('FCGI_BEGIN_REQUEST', 1);
define('FCGI_ABORT_REQUEST', 2);
define('FCGI_END_REQUEST', 3);
define('FCGI_PARAMS', 4);
define('FCGI_STDIN', 5);
define('FCGI_STDOUT', 6);
define('FCGI_STDERR', 7);
define('FCGI_DATA', 8);
define('FCGI_GET_VALUES', 9);
define('FCGI_GET_VALUES_RESULT', 10);

define('FCGI_RESPONDER', 1);
define('FCGI_KEEP_CONN', 1);

define('FCGI_DEFAULT_CONTENT_TYPE', 'plain/text');
define('FCGI_DEFAULT_GATEWAY_INTERFACE', 'FastCGI/1.0');

define('FCGI_SCRIPT_FILENAME', 'SCRIPT_FILENAME');
define('FCGI_QUERY_STRING', 'QUERY_STRING');
define('FCGI_CONTENT_TYPE', 'CONTENT_TYPE');
define('FCGI_CONTENT_LENGTH', 'CONTENT_LENGTH');
define('FCGI_REQUEST_METHOD', 'REQUEST_METHOD');
define('FCGI_DOCUMENT_ROOT', 'DOCUMENT_ROOT');
define('FCGI_GATEWAY_INTERFACE', 'GATEWAY_INTERFACE');

define('FCGI_METHOD_GET', 'GET');
define('FCGI_METHOD_POST', 'POST');
define('FCGI_RESULT_CONTENT_TYPE', 'Content-type');

function fcgi_encode($type, &$content, $id = 1) {
    $len = strlen($content);
    $packet = chr(FCGI_VERSION_1) . chr($type) 
        . chr(($id >> 8) & 0xFF) . chr($id & 0xFF)  // requestId
        . chr((int)($len/256)) . chr($len%256)      // contentLength
        . chr(0) . chr(0)                           // paddingLength
        . $content;
        
    return $packet;
}

function fcgi_param($name, $value) {
    $nlen = strlen($name);
    $vlen = strlen($value);

    $nvpair = $nlen < 128 ? chr($nlen) : 
        chr(($nlen >> 24) | 0x80) . 
        chr(($nlen >> 16) & 0xFF) . 
        chr(($nlen >> 8) & 0xFF) . 
        chr($nlen & 0xFF);
  
    $nvpair .= $vlen < 128 ? chr($vlen) :
        chr(($vlen >> 24) | 0x80) . 
        chr(($vlen >> 16) & 0xFF) . 
        chr(($vlen >> 8) & 0xFF) . 
        chr($vlen & 0xFF);
    return $nvpair . $name . $value;
}

function fcgi_decode(&$data) {
	$len = strlen($data);
    if ($len < 8) {
        return null;
    }
  
    $packet = new stdClass();
    $packet->version = ord($data[0]);
    $packet->type = ord($data[1]);
    $packet->requestId = (ord($data[2]) << 8) + ord($data[3]);
    $packet->contentLength = (ord($data[4]) << 8) + ord($data[5]);
    $packet->paddingLength = ord($data[6]);
    $packet->length = $packet->contentLength + $packet->paddingLength;
    if ($len > 8 && $packet->contentLength > 0) {
    	$packet->content = substr($data, 8, $packet->contentLength);
    }
  
    return $packet;
}

class FastCgiRequest {
	private $id = 0;
	private $params = array();
	private $content = null;
	
	public function __construct($script, $content = null, $isGet = false, $id = 1) {
		$this->setId($id);
		$this->setMethod($isGet);
		$this->setScript($script);
		$this->setContent($content);
		$this->setParam(FCGI_GATEWAY_INTERFACE, FCGI_DEFAULT_GATEWAY_INTERFACE);
	}
	
	public function setParam($name, $value) {
		$this->params[$name] = $value;
	}
	
	public function getParam($name) {
		return array_key_exists($name, $this->params) ?
		    $this->params[$name] : null;
	}
	
	public function __set($name, $value) {
		$this->setParam($name, $value);
	}
	
	public function __get($name) {
		return $this->getParam($name);
	}
	
	public function __isset($name) {
		return array_key_exists($name, $this->params);
	}
	
	public function setScript($script, $root = null) {
		$this->setParam(FCGI_SCRIPT_FILENAME, $script);
		if (strlen($root) >= 0) {
			$this->setParam(FCGI_DOCUMENT_ROOT, $root);
		}
	}
	
	public function setContent($content, $type = FCGI_DEFAULT_CONTENT_TYPE) {
		if (is_null($content)) {
			return;
		}
		
		$len = strlen($content);
		$this->content = $content;
		$this->setParam(FCGI_CONTENT_LENGTH, $len);
		$this->setParam(FCGI_CONTENT_TYPE, $type);
	}
	
	public function setId($id) {
		$this->id = $id;
	}
	
	public function setMethod($isGet) {
		$this->setParam(FCGI_REQUEST_METHOD, 
		    $isGet ? FCGI_METHOD_GET : FCGI_METHOD_POST);
	}
	
	public function __toString() {
		$nullPacket = null;		
		$header = chr(0) . chr(FCGI_RESPONDER) . 		// Role
		    chr(FCGI_KEEP_CONN) .              			// Keepalive
		    chr(0) . chr(0) . chr(0) . chr(0) . chr(0);	// Reserved bytes
		$packet = fcgi_encode(FCGI_BEGIN_REQUEST, $header);
		
		foreach ($this->params as $name => $value) {
			$data = fcgi_param($name, $value);
			$packet .= fcgi_encode(FCGI_PARAMS, $data);
		}
		$packet .= fcgi_encode(FCGI_PARAMS, $nullPacket);
		
		$offset = 0;
		$remain = intval($this->getParam(FCGI_CONTENT_LENGTH));
		while ($remain > 0) {
			$size = $remain > 0x0FFFF ? 0xFFFF : $remain;
			$data = substr($this->content, $offset, $size);
			$packet .= fcgi_encode(FCGI_STDIN, $data);
			
			$offset += $size;
			$remain -= $size;
		}
		$packet .= fcgi_encode(FCGI_STDIN, $nullPacket);
		
		return $packet;
	}
};

class FastCgiClient {
	private $socket = null;
	
    public function __construct($host, $port) {
        if (!is_null($host) && !is_null($port)) {
        	$this->connect($host, $port);
        }	
    }
    
    public function __destruct() {
    	$this->close();
    }
    
    public function connect($host, $port) {
    	if (!is_null($this->socket)) {
    		throw new Exception("AlreadyConnected");
    	}
    	
    	$this->socket = fsockopen($host, $port);
    }
    
    public function close() {
    	if (is_null($this->socket)) {
    		return;
    	}
    	
    	fclose($this->socket);
    	$this->socket = null;
    }
    
    public function write($data) {
    	if (is_null($this->socket)) {
    		throw new Exception("NotYetConnected");
    	}
    	
    	if (!is_null($data)) {
    		return fwrite($this->socket, $data);
    	}
    	
    	return 0;
    }
    
    public function read() {
        if (is_null($this->socket)) {
    		throw new Exception("NotYetConnected");
    	}
    		
    	$packet = fread($this->socket, 8);
    	if ($packet === false) {
    		return null;
    	}
    	
    	$header = fcgi_decode($packet);
    	if (is_null($header) || $header->length <= 0) {
    		return $header;
    	}
    	
    	$packet .= fread($this->socket, $header->length);
    	$result = fcgi_decode($packet);
    	return $result;
    }
    
    public function execute($request) {
    	if ($this->write(strval($request)) <= 0) {
    		return null;
    	}
    	
    	$response = new stdClass();
    	$response->stdout = null;
    	$response->stderr = null;
    	$response->appStatus = 0;
    	$response->cgiStatus = 0;
    	
    	while (true) {
    		$packet = $this->read();
    		if (is_null($packet)) {
    			return null;
    		}
    		
    		switch ($packet->type) {
    			case FCGI_STDERR:
    				$response->stderr .= $packet->content;
    				break;
    			case FCGI_STDOUT:
    				$response->stdout .= $packet->content;
    				break;
    			case FCGI_END_REQUEST:
    				$response->appStatus = ord($packet->content[0]) << 24
    				    + ord($packet->content[1]) << 16
    				    + ord($packet->content[2]) << 8
    				    + ord($packet->content[3]);
    				$response->cgiStatus = ord($packet->content[4]);
    				return $response;
    			default:
    				break;
    		}
    	}
    }
};

