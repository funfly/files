#ifndef __SMB_LM_SMBVAL_MD4_H
#define __SMB_LM_SMBVAL_MD4_H

extern void mdfour(unsigned char *out, unsigned char *in, int n);

#endif /* __SMB_LM_SMBVAL_MD4_H */
