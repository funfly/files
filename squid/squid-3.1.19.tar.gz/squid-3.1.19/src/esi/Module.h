#ifndef SQUID_ESI_MODULE_H
#define SQUID_ESI_MODULE_H

namespace Esi
{

extern void Init();
extern void Clean();

}; // namespace Esi

#endif /* SQUID_ESI_MODULE_H */
