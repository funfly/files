var mod = require('./mod.js');
mod.hello();
mod.hello();
debugger;
