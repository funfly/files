exports.loaded = require('target');
exports.module = module;
